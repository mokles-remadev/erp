## Module <pos_dashboard>

#### 09.04.2021
#### Version 14.0.1.0.0

##### Initial Commit for pos_dashboard

